# Skill 通用樣板 — 使用指南

> 適用於 **Claude Skills** 與 **Google Antigravity Skills** 的跨平台樣板。

---

## 資料夾結構總覽

```
my-skill/
├── SKILL.md               ← 核心指令（必填，≤500 行）
├── agents/                ← 代理人指令（建議）
│   ├── researcher.md      ← 研究員：資料蒐集與分析
│   ├── writer.md          ← 撰寫者：內容產出
│   └── reviewer.md        ← 審查員：品質檢查
├── scripts/               ← 可執行腳本（選填）
│   └── validate.py        ← 範例：格式驗證腳本
├── references/            ← 按需載入的參考文件（選填）
│   ├── technical-guide.md ← 技術規格手冊
│   └── style-guide.md     ← 撰寫風格指南
└── assets/                ← 輸出模板與靜態素材（選填）
    └── README.md          ← 資料夾說明
```

## 三層載入機制（Progressive Disclosure）

兩個平台共用相同的「漸進式揭露」設計：

```
第一層 ─ Metadata（永遠在 context 中，~100 字）
│        → SKILL.md 的 YAML frontmatter（name + description）
│        → AI 用這層決定「要不要啟用這個 Skill」
│
第二層 ─ SKILL.md 本體（觸發後載入，≤500 行）
│        → 核心工作流程、代理人分工表、輸出格式
│        → 包含指向第三層資源的「路標」
│
第三層 ─ 子資料夾資源（按需載入，無上限）
         → agents/     代理人的詳細指令
         → references/ 技術文件、風格指南
         → scripts/    可直接執行，不需載入 context
         → assets/     模板檔案，供代理人參考或複製
```

## 跨平台部署指南

### Claude（claude.ai / Claude Code）

安裝位置：
- 使用者自訂 Skill → `/mnt/skills/user/my-skill/`
- 打包為 `.skill` 檔案上傳

觸發方式：
- Claude 根據 `available_skills` 中的 description 自動判斷
- 使用 `view` 工具讀取子資料夾資源

注意事項：
- `agents/` 在 Claude.ai 中無法平行執行（無 subagent）
- Claude 會依序扮演每個代理人角色
- Claude Code 支援 subagent 平行執行

### Google Antigravity

安裝位置：
- 全域 Skill → `~/.gemini/antigravity/skills/my-skill/`
- 專案 Skill → `<workspace>/.agents/skills/my-skill/`

觸發方式：
- Antigravity 根據 SKILL.md frontmatter 的 description 自動判斷
- 與 Claude 的觸發機制幾乎相同

搭配使用：
- `AGENTS.md`（專案根目錄）→ 跨工具的共用規則
- `GEMINI.md`（專案根目錄）→ Antigravity 專屬規則
- Skill 是「按需載入」，Rules 是「永遠生效」，兩者互補

注意事項：
- Antigravity 支援 Manager View 多代理人平行執行
- `agents/` 中的代理人可對應到 Antigravity 的不同 workspace
- 腳本執行依賴 Terminal Policy 設定

## 快速開始

1. 複製本樣板資料夾，改名為你的 Skill 名稱
2. 編輯 `SKILL.md` 的 frontmatter（name + description）
3. 編輯 `SKILL.md` 的工作流程章節
4. 根據需要修改或刪除 `agents/` 中的代理人
5. 放入實際的參考文件到 `references/`
6. 放入輸出模板到 `assets/`
7. 修改或刪除 `scripts/` 中的腳本
8. 刪除所有 `<!-- 註解 -->` 提示文字

## 設計原則

- **模組化**：每個檔案只負責一件事
- **漸進揭露**：不需要的資訊不要載入
- **平台無關**：核心結構兩平台通用
- **可擴展**：隨需求成長，不需要一開始就用滿所有資料夾
