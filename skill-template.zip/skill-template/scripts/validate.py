#!/usr/bin/env python3
"""
validate.py — 輸出格式驗證腳本（範例）

用途：檢查產出的文件是否符合 SKILL.md 定義的輸出格式。
使用方式：python scripts/validate.py --input <filepath>

📌 這是範例腳本，請根據實際需求修改。
   腳本可直接執行，不需要載入 context。
"""

import argparse
import sys


def validate(filepath: str) -> list[str]:
    """驗證文件格式，回傳錯誤清單。"""
    errors = []

    try:
        with open(filepath, "r", encoding="utf-8") as f:
            content = f.read()
    except FileNotFoundError:
        return [f"找不到文件：{filepath}"]

    # === 在此加入你的驗證規則 ===

    # 範例：檢查是否有標題
    if not content.startswith("#"):
        errors.append("文件缺少標題（應以 # 開頭）")

    # 範例：檢查必要章節
    required_sections = ["## 摘要", "## 主要內容", "## 結論與建議"]
    for section in required_sections:
        if section not in content:
            errors.append(f"缺少必要章節：{section}")

    return errors


def main():
    parser = argparse.ArgumentParser(description="驗證輸出格式")
    parser.add_argument("--input", required=True, help="要驗證的文件路徑")
    args = parser.parse_args()

    errors = validate(args.input)

    if errors:
        print("❌ 驗證失敗：")
        for e in errors:
            print(f"  - {e}")
        sys.exit(1)
    else:
        print("✅ 驗證通過")
        sys.exit(0)


if __name__ == "__main__":
    main()
